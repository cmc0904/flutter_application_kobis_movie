import 'package:flutter/material.dart';

class DetailPage extends StatelessWidget {
  String koreaTitle, englishTitle;
  DetailPage({super.key, required this.koreaTitle});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Row(children: [Text("한국어 제목"), SizedBox(width: 20,), Text(koreaTitle)],),

          Row(children: [Text("한국어 제목"), SizedBox(width: 20,), Text(koreaTitle)],),
      ]),
    );
  }
}