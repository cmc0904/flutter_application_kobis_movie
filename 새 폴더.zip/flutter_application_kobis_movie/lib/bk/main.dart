import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_application_kobis_movie/detailPage.dart';
import 'kobis_api.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({
    super.key,
  });

  @override
  State<MainPage> createState() => _MainPageState();
}

class Movie extends StatelessWidget {
  String title, OpenDt, rank, id;
  var API = MovieApi();
  Movie(
    this.OpenDt,
    this.rank,
    this.title,
    this.id,
  );

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Text("$rank위"),
      title: Text(title),
      subtitle: Text(OpenDt),
      onTap: () async {
        var a = await API.searchDetailPage(id);

        newMethod(context, a);
        // movieDetailPage();
      },
    );
  }

  void newMethod(BuildContext context, dynamic json) {
    // print(API.searchDetailPage(id));
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return DetailPage(json: json,);
        },
      )
    );
  }
}

class _MainPageState extends State<MainPage> {
  String selectedDayText = "날짜를 선택해주세요";
  var API = MovieApi();

  List<Widget> lists = [];
  void showCal() async {
    lists = [];
    var dt = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2023, 3, 2),
      lastDate: DateTime(2023, 7, 30),
    );

    if (dt != null) {
      var datas = await API.search(dt.toString().split(" ")[0].replaceAll("-", ""));
      setState(() {
        selectedDayText = dt.toString().split(" ")[0];
      
        for (var data in datas) {
          lists.add(
            Movie(
              data['openDt'],
              data['rank'],
              data['movieNm'],
              data['movieCd'],
            ),
          );
        }
        // print(lists);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              const Icon(
                Icons.search,
                color: Colors.black12,
              ),
              const SizedBox(
                width: 8,
              ),
              Flexible(
                flex: 1,
                child: SizedBox(
                  child: Text(
                    selectedDayText,
                    style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                  width: 2000,
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              TextButton(
                onPressed: () {
                  showCal();
                },
                child: const Text('검색'),
              ),
            ],
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.all(8),
          children: lists,
        ),
      ),
    );
  }
}
