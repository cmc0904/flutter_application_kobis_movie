import 'dart:convert';

import 'package:flutter/material.dart';

class DetailPage extends StatelessWidget {
  dynamic json;
  DetailPage({super.key, required this.json});


  @override
  Widget build(BuildContext context) {
    print(json);
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Column(
          children: [
            Text(json['movieNm'], style: TextStyle(fontSize: 20),),
            Text(json['movieNmEn'], style: TextStyle(fontSize: 15),),
          ],
        )
        
      ),

      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
          
            Column(
              children: [
                Row(
                  children: [
                    Text("배우", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                  ],
                ),
                SizedBox(height: 7,),
                Wrap(
                  direction: Axis.horizontal, // 나열 방향
                  alignment: WrapAlignment.start, // 정렬 방식
                  spacing: 5, // 좌우 간격
                  runSpacing: 5, // 상하 간격
                  children: [
                    for(var i in json['actors'])
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: const Color(0xffdddddd),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(i['peopleNm']),
                    ),
                  ],
                ),
              ],
            )

          ]
        ),
      ),


      
    );
  }
}